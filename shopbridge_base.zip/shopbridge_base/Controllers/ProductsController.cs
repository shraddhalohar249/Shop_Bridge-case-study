﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Shopbridge_base.Data;
using Shopbridge_base.Domain.Models;
using Shopbridge_base.Domain.Services.Interfaces;

namespace Shopbridge_base.Controllers
{

    [Route("api/products")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ProductsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> AddProduct(Product product)
        {
            // Validate the input data
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Add the new product to the database
            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            return Ok(product);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(int id, Product product)
        {
            // Find the product by ID
            var existingProduct = await _context.Products.FindAsync(id);
            if (existingProduct == null)
                return NotFound();

            // Update the product fields
            existingProduct.Product_Name = product.Product_Name;
            existingProduct.Product_Description = product.Product_Description;
            existingProduct.Product_Category = product.Product_Category;
            // Update any additional fields here

            // Save the changes to the database
            await _context.SaveChangesAsync();

            return Ok(existingProduct);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            // Find the product by ID
            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            // Remove the product from the database
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            return Ok();
        }

        [HttpGet]
        public async Task<IActionResult> GetProducts()
        {
            // Retrieve all products from the database
            var products = await _context.Products.ToListAsync();

            return Ok(products);
        }
    }


}

namespace Shopbridge_base
{
    class Shopbridge_Context
    {
    }
}